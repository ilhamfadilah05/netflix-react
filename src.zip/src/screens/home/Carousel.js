import { StyleSheet, Text, View, SafeAreaView, Image, TextInput, TouchableOpacity, FlatList, ActivityIndicator } from 'react-native';
import React, { useState, useEffect } from 'react';


const Carousel = ({ }) => {
    return (
        <Text style={{ fontSize: 30 }}> INI CAROUSEL, DIBIKIN DI SINI YAA</Text>
    );
}

export default Carousel;